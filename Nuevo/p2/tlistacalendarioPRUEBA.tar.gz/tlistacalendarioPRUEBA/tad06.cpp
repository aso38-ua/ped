#include <iostream>

using namespace std;

#include "tcalendario.h"
#include "tlistacalendario.h"

int
main(void)
{
  TListaCalendario a, b, c;
  TListaPos p, q;
  TNodoCalendario n, m;

  cout << "No hace nada" << endl;

  return 0;
}
